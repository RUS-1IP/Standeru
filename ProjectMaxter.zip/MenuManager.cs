using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuManager : MonoBehaviour
{
    public GameObject levelPanel;

    public void LevelOpen()
    {
        levelPanel.SetActive(true);
    }

    public void Nazad()
    {
        levelPanel.SetActive(false);
    }

    public void Quit()
    {
        Application.Quit();
    }

    public void SceneOpen(int SceneLevel)
    {
        SceneManager.LoadScene(SceneLevel);
    }
}
