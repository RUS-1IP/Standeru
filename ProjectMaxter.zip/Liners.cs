using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Liners : MonoBehaviour
{
    private LineRenderer lineRenderer;
    private Vector2 lastPosition;

    private void Start()
    {
        lineRenderer = gameObject.AddComponent<LineRenderer>();
        lineRenderer.startWidth = 0.1f;
        lineRenderer.endWidth = 0.1f;
        lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
        lineRenderer.startColor = Color.blue;
        lineRenderer.endColor = Color.blue;
        lineRenderer.sortingOrder = -1;

        lastPosition = transform.position;
        lineRenderer.positionCount = 1;
        lineRenderer.SetPosition(0, lastPosition);
    }

    public void AddPosition(Vector2 newPosition)
    {
        lineRenderer.positionCount++;
        lineRenderer.SetPosition(lineRenderer.positionCount - 1, newPosition);
        lastPosition = newPosition;
    }

    public void ClearLines()
    {
        lineRenderer.positionCount = 1;
        lineRenderer.SetPosition(0, transform.position);
    }
}

