using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Player : MonoBehaviour
{
    [Header("Movement Settings")]
    public float moveSpeed = 2f;
    public float rotationSpeed = 90f;

    [Header("Movement Constraints")]
    public float minX = -10f;
    public float maxX = 10f;
    public float minY = -10f;
    public float maxY = 10f;

    [Header("UI References")]
    public TMP_InputField commandInput;
    public Button executeButton;
    public Text outputText;
    public Text positionText;


    private Vector2 startPosition;
    private Quaternion startRotation;
    private bool isExecuting = false;
    private List<string> commandHistory = new List<string>();
    private Coroutine currentExecution;

    private void Start()
    {
        startPosition = transform.position;
        startRotation = transform.rotation;

        executeButton.onClick.AddListener(ExecuteCommands);
        UpdatePositionText();
    }

    private void ExecuteCommands()
    {
        if (isExecuting)
        {
            OutputMessage("���������� ��� ����");
            return;
        }

        string commands = commandInput.text.Trim().ToLower();
        commandInput.text = "";

        if (string.IsNullOrEmpty(commands))
        {
            OutputMessage("������� �������");
            return;
        }

        if (currentExecution != null)
        {
            StopCoroutine(currentExecution);
        }

        currentExecution = StartCoroutine(ExecuteCommandsCoroutine(commands));
    }

    private IEnumerator ExecuteCommandsCoroutine(string commands)
    {
        isExecuting = true;
        executeButton.interactable = false;

        string[] commandArray = commands.Split(',');
        List<string> cleanCommands = new List<string>();

        foreach (string cmd in commandArray)
        {
            string cleanCmd = cmd.Trim();
            if (!string.IsNullOrEmpty(cleanCmd))
            {
                cleanCommands.Add(cleanCmd);
                commandHistory.Add(cleanCmd);
            }
        }

        foreach (string command in cleanCommands)
        {
            yield return StartCoroutine(ProcessCommandCoroutine(command));
        }

        isExecuting = false;
        executeButton.interactable = true;
        currentExecution = null;
        OutputMessage("��� ������� ���������!");
    }

    private IEnumerator ProcessCommandCoroutine(string command)
    {
        string[] parts = command.Split(' ');
        string action = parts[0];
        int value = 1;

        if (parts.Length > 1)
        {
            if (!int.TryParse(parts[1], out value))
            {
                OutputMessage($"������������ �������� � �������: {command}");
                yield break;
            }
        }

        switch (action)
        {
            case "�����":
            case "up":
                yield return StartCoroutine(MoveCoroutine(Vector2.up, 2.1f * value, command));
                break;

            case "����":
            case "down":
                yield return StartCoroutine(MoveCoroutine(Vector2.down, 2.1f * value, command));
                break;

            case "�����":
            case "left":
                yield return StartCoroutine(MoveCoroutine(Vector2.left, 2.26f * value, command));
                break;

            case "������":
            case "right":
                yield return StartCoroutine(MoveCoroutine(Vector2.right, 2.26f * value, command));
                break;

            case "�����":
            case "home":
                GoHome();
                OutputMessage($"���������: {command}");
                break;

            case "�������":
            case "history":
                ShowHistory();
                break;

            default:
                OutputMessage($"����������� �������: {command}");
                break;
        }
    }

    private IEnumerator MoveCoroutine(Vector2 direction, float distance, string originalCommand)
    {
        Vector2 startPos = transform.position;
        Vector2 endPos = startPos + direction * distance;

        // �������� ������ ����� ���������
        if (!IsPositionWithinBounds(endPos))
        {
            OutputMessage($"������: ���������� ������� ���� ({endPos.x:F1}, {endPos.y:F1})");
            executeButton.interactable = true;
            yield break;
        }

        float journeyLength = Vector2.Distance(startPos, endPos);
        float startTime = Time.time;

        while (Vector2.Distance(transform.position, endPos) > 0.01f)
        {
            float distCovered = (Time.time - startTime) * moveSpeed;
            float fractionOfJourney = distCovered / journeyLength;
            transform.position = Vector2.Lerp(startPos, endPos, fractionOfJourney);
            yield return null;
        }

        transform.position = endPos;
        UpdatePositionText();
        OutputMessage($"���������: {originalCommand}");
    }

    private bool IsPositionWithinBounds(Vector2 position)
    {
        return position.x >= minX && position.x <= maxX &&
               position.y >= minY && position.y <= maxY;
    }



    private void GoHome()
    {
        transform.position = startPosition;
        transform.rotation = startRotation;
        UpdatePositionText();
    }

    private void ShowHistory()
    {
        string history = "������� ������:\n";
        foreach (string cmd in commandHistory)
        {
            history += $"- {cmd}\n";
        }
        OutputMessage(history);
    }

    private void UpdatePositionText()
    {
        positionText.text = $"�������: {transform.position.x:F1}, {transform.position.y:F1}\n" +
                         $"�������: {transform.eulerAngles.z:F0}�\n" +
                         $"�������: X({minX:F1}-{maxX:F1}), Y({minY:F1}-{maxY:F1})\n";
    }

    private void OutputMessage(string message)
    {
        outputText.text += $"{message}\n";
        Canvas.ForceUpdateCanvases();
    }
}