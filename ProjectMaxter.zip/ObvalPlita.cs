using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObvalPlita : MonoBehaviour
{
    public SpriteRenderer obvalPlitas;
    public Collider2D col;

    IEnumerator On()
    {
        yield return new WaitForSeconds(2f);
        obvalPlitas.enabled = false;
        col.enabled = true;
        StartCoroutine(Off());
    }

    IEnumerator Off()
    {
        yield return new WaitForSeconds(2f);
        obvalPlitas.enabled = true;
        col.enabled = false;
        StartCoroutine(On());
    }
    private void Start()
    {
        StartCoroutine(On());
    }
}
